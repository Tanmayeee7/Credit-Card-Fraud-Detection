import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

#shift+enter
#copy csv file path

# ------------------------------------------------------------------------

#loading the dataset
dataset = pd.read_csv('dataset/transactions.csv')
print(dataset.head())
print(dataset.tail())

# -------------------------------------------------------------------

#dataset info
dataset.info

#checking the missing values in each column
dataset.isnull().sum()
#no missing values found

#0=legit, 1=fraud
#distribution of legit, fraud transactions
dataset['Class'].value_counts
# 0 = 284315, 1 = 492
#imbalanced as 0 has 90% data, 1 has less

#separating data for analysis
legit = dataset[dataset.Class == 0]
fraud = dataset[dataset.Class == 1]  

#printing the shape
print(legit.shape) #284319, 31
print(fraud.shape)  #492, 31

#statistical measures
legit.Amount.describe() #shows count, mean, std, min, max, name, denoted in percentile
fraud.Amount.describe()
# observation: mean of frayd transactions is greater than that of legit

# compare mean values for both transactions
dataset.groupby('Class').mean()

# ---------------------------------------------------------------------------------------------------

#Under sampling
# build a sample dataset containing similar distribution like legit, fraud transaction
#fraud transactions = 492
#in legit, randomly take 492 transactions, join it with fraud transactions
#we will have 492 fraug, 492 legit --- uniform distribution
legit_sample = legit.sample(n=492) #random sampling

#concatenating two data frames : legit_sample, fraud
new_dataset = pd.concat([legit_sample, fraud], axis=0)
# axis 0 = fraud is added below legit_sample
# axis 1 = fraud columns are added next to legit_sample columns

new_dataset.head()
new_dataset.tail()
new_dataset['Class'].value_counts()
new_dataset.groupby('Class').mean()
#shows the dataset ke values havent changed much
#if sample is a bad sample, mean values are very different from the original dataset

# ---------------------------------------------------------------------------------------------

#splitting the dataset into features and targets (0,1)
X = new_dataset.drop(columns='Class', axis=1)
Y = new_dataset['Class']

print(X) #has 30 columns instead of 31
print(Y)

#splitting data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, stratify=Y, random_state=2) 
#0.2 is 20% of data

print(X.shape, X_train.shape, X_test.shape)   #data is split succesffully in train and test

# ---------------------------------------------------------------------------------------------------
#                      MACHINE LEARNING MODEL

#using logistic regression as dataset has binary classification
model = LogisticRegression(solver='saga', max_iter=10000, class_weight = 'balanced')

#training the LogisticRegression model with training data
model.fit(X_train, Y_train)

# ---------------------------------------------------------------------------------------------------
#                      ACCURACY SCORE

#accuracy on training data
X_train_prediction = model.predict(X_train)
training_data_accuracy = accuracy_score(X_train_prediction, Y_train)
print("Accuracy on training data: ", training_data_accuracy) 
#0.941550; +0.75 accuracy score is a good score

#training - solving bookish, known problems
#test - your compatibility in solving out-of-syllabus, unkown questions

#accuracy on test data
X_test_prediction = model.predict(X_test)
test_data_accuracy = accuracy_score(X_test_prediction, Y_test)
print("Accuracy on test data: ", test_data_accuracy) 
#0.93, accuracy score of test is similar to that of training 
#doing PYQ

