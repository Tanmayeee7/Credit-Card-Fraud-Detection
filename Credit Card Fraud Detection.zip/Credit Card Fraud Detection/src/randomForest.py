import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# -------------------------------------------------------------------

#loading dataset
dataset = pd.read_csv('dataset/transactions.csv')
print(dataset.head())
print(dataset.tail())

# ------------------------------------------------------------------------

#dataset info
dataset.info

#checking the missing values in each column
dataset.isnull().sum()

#0=legit, 1=fraud
#distribution of legit, fraud transactions
dataset['Class'].value_counts

# separating data for analysis
legit = dataset[dataset.Class == 0]
fraud = dataset[dataset.Class == 1]

#printing the shape
print(legit.shape)
print(fraud.shape)

#statistical measures
legit.Amount.describe() #shows count, mean, std, min, max, name, denoted in percentile
fraud.Amount.describe()

#compare mean values for both transactions
dataset.groupby('Class').mean()

# ---------------------------------------------------------------------------------------------

#under-sampling
legit_sample = legit.sample(n=492)

#concatenate legit_sample, fraud
new_dataset = pd.concat([legit_sample, fraud], axis=0)


new_dataset.head()
new_dataset.tail()
new_dataset['Class'].value_counts()
new_dataset.groupby('Class').mean()
#shows the mean values of new and original datasets havent changed much

# ------------------------------------------------------------------------------------------------

#splitting dataset
X = new_dataset.drop(columns='Class', axis=1)
Y = new_dataset['Class']
print(X) #has 30 columns instead of 31
print(Y)

#splitting data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, stratify=Y, random_state=2)
print(X.shape, X_train.shape, X_test.shape)

# ------------------------------------------------------------------------------------------------
#                        MACHINE LEARNING MODEL

#using random forest classifier
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)

#training model
model.fit(X_train, Y_train)

from sklearn.model_selection import GridSearchCV
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'class_weight': ['balanced', 'balanced_subsample']
}

grid_search = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train, Y_train)
best_model = grid_search.best_estimator_

# ---------------------------------------------------------------------------------------
#                          ACCURACY SCORE


from sklearn.metrics import classification_report, roc_auc_score

Y_pred = model.predict(X_test)
print(classification_report(Y_test, Y_pred))
print("ROC-AUC Score:", roc_auc_score(Y_test, model.predict_proba(X_test)[:, 1]))

from sklearn.model_selection import cross_val_score

cv_scores = cross_val_score(model, X, Y, cv=5, scoring='accuracy')
print("Cross-Validation Accuracy: ", cv_scores.mean())


from sklearn.metrics import accuracy_score

# Predicting the test data
X_test_prediction = model.predict(X_test)

# Test Accuracy
test_data_accuracy = accuracy_score(Y_test, X_test_prediction)
print("Accuracy on test data:", test_data_accuracy)
